import { StyleSheet, Text, View } from "react-native";

export function AdBanner() {
  return <View style={styles.container}><Text style={styles.text}>مساحة الإعلان تظهر داخل نسخة Android</Text></View>;
}

const styles = StyleSheet.create({ container: { minHeight: 50, alignItems: "center", justifyContent: "center" }, text: { color: "#8A9A90", fontSize: 10 } });
