// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * Add your SF Symbols to Material Icons mappings here.
 * - see Material Icons in the [Icons Directory](https://icons.expo.fyi).
 * - see SF Symbols in the [SF Symbols](https://developer.apple.com/sf-symbols/) app.
 */
const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "book.fill": "menu-book",
  "quote.bubble.fill": "format-quote",
  "lightbulb.fill": "lightbulb",
  "checkmark.circle": "check-circle",
  "checkmark.circle.fill": "check-circle",
  "star": "star-outline",
  "star.fill": "star",
  "circle.grid.2x2.fill": "radio-button-checked",
  "trophy.fill": "emoji-events",
  "person.fill": "person",
  "person.2.fill": "people",
  "person.3.fill": "groups",
  "lock.fill": "lock",
  "info.circle.fill": "info",
  "arrow.right.square.fill": "logout",
  "arrow.counterclockwise": "refresh",
  "arrow.left": "arrow-back",
  "music.note": "music-note",
  "pause.fill": "pause",
  "play.fill": "play-arrow",
  "mic.fill": "mic",
  "message.fill": "message",
  "camera.fill": "photo-camera",
  "stop.fill": "stop",
  "circle": "radio-button-unchecked",
  "chevron.up": "keyboard-arrow-up",
  "chevron.down": "keyboard-arrow-down",
  "xmark.circle.fill": "cancel",
} as IconMapping;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 * This ensures a consistent look across platforms, and optimal resource usage.
 * Icon `name`s are based on SF Symbols and require manual mapping to Material Icons.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
