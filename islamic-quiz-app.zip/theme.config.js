/** @type {const} */
const themeColors = {
  primary: { light: '#0F5132', dark: '#63B982' },
  background: { light: '#FFFFFF', dark: '#FFFFFF' },
  surface: { light: '#F7FAF8', dark: '#F7FAF8' },
  foreground: { light: '#14221A', dark: '#14221A' },
  muted: { light: '#6B7B71', dark: '#6B7B71' },
  border: { light: '#DDE8E0', dark: '#DDE8E0' },
  success: { light: '#2E8B57', dark: '#72D39A' },
  warning: { light: '#B7791F', dark: '#F0C36A' },
  error: { light: '#B83232', dark: '#F08A8A' },
};

module.exports = { themeColors };
