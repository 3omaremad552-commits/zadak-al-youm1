import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { getProfile } from "@/lib/local-profile";
import { AdBanner } from "@/components/ad-banner";

export default function HomeScreen() {
  const colors = useColors();
  const [profile, setProfile] = useState({ name: "ضيف", points: 0, correctAnswers: 0, tasbeehCount: 0 });

  useEffect(() => {
    const load = () => getProfile().then((value) => setProfile((current) => ({ ...current, ...value })));
    load();
    const timer = setInterval(load, 700);
    return () => clearInterval(timer);
  }, []);

  const isGuest = profile.name === "ضيف";
  const statItems = [
    { label: "التسبيحات", value: profile.tasbeehCount, icon: "circle.grid.2x2.fill" as const },
    { label: "إجابات صحيحة", value: profile.correctAnswers, icon: "checkmark.circle.fill" as const },
    { label: "النقاط", value: profile.points, icon: "trophy.fill" as const },
  ];

  return (
    <ScreenContainer className="px-4" containerClassName="bg-[#F8FAF9]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <View style={styles.headerCopy}>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>زادك اليوم</Text>
            <Text style={[styles.greeting, { color: colors.foreground }]}>السلام عليكم، {profile.name}</Text>
            <Text style={[styles.subtitle, { color: colors.muted }]}>خطوة صغيرة كل يوم تصنع أثرًا كبيرًا</Text>
          </View>
          <View style={[styles.logoMark, { backgroundColor: colors.primary }]}>
            <IconSymbol name="book.fill" size={24} color="#FFFFFF" />
          </View>
        </View>

        <View style={[styles.hero, { backgroundColor: colors.primary }]}>
          <View style={styles.heroText}>
            <Text style={styles.heroLabel}>إجمالي نقاطك</Text>
            <Text style={styles.heroPoints}>{profile.points.toLocaleString("ar-EG")}</Text>
            <Text style={styles.heroHint}>{isGuest ? "سجّل دخولك لحفظ تقدمك" : "استمر في التقدم اليوم"}</Text>
          </View>
          <View style={styles.trophyCircle}>
            <IconSymbol name="trophy.fill" size={26} color="#A87918" />
          </View>
        </View>

        <View style={styles.statsRow}>
          {statItems.map((item) => (
            <View key={item.label} style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <IconSymbol name={item.icon} size={18} color={colors.primary} />
              <Text style={[styles.statValue, { color: colors.foreground }]}>{item.value.toLocaleString("ar-EG")}</Text>
              <Text style={[styles.statLabel, { color: colors.muted }]}>{item.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>اكتشف زادك اليوم</Text>
          <Text style={[styles.sectionHint, { color: colors.muted }]}>اختر نشاطًا</Text>
        </View>

        <Pressable onPress={() => router.push("/tasbeeh")} style={({ pressed }) => [styles.featureCard, styles.tasbeehCard, pressed && styles.pressed]}>
          <View style={styles.cardIcon}><IconSymbol name="circle.grid.2x2.fill" size={25} color="#11633D" /></View>
          <View style={styles.cardCopy}><Text style={styles.featureTitle}>المسبحة الرقمية</Text><Text style={styles.featureText}>سبّح واكسب نقطة لكل تسبيحة</Text></View>
          <IconSymbol name="chevron.right" size={22} color="#11633D" />
        </Pressable>

        <Pressable onPress={() => router.push("/quiz")} style={({ pressed }) => [styles.featureCard, styles.quizCard, pressed && styles.pressed]}>
          <View style={[styles.cardIcon, { backgroundColor: "#E1F0FA" }]}><IconSymbol name="book.fill" size={25} color="#2373A8" /></View>
          <View style={styles.cardCopy}><Text style={styles.featureTitle}>مسابقة اليوم</Text><Text style={styles.featureText}>أجب إجابة صحيحة واربح 10 نقاط</Text></View>
          <IconSymbol name="chevron.right" size={22} color="#2373A8" />
        </Pressable>

        <Pressable onPress={() => router.push("/leaderboard")} style={({ pressed }) => [styles.featureCard, styles.rankCard, pressed && styles.pressed]}>
          <View style={[styles.cardIcon, { backgroundColor: "#FFF1C7" }]}><IconSymbol name="trophy.fill" size={25} color="#AA791B" /></View>
          <View style={styles.cardCopy}><Text style={styles.featureTitle}>لوحة الصدارة</Text><Text style={styles.featureText}>شاهد أصحاب أعلى النقاط الحقيقية</Text></View>
          <IconSymbol name="chevron.right" size={22} color="#AA791B" />
        </Pressable>

        <AdBanner />
        <Text style={[styles.privacyNote, { color: colors.muted }]}>تظهر في الصدارة الحسابات الحقيقية فقط.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { width: "100%", maxWidth: 430, alignSelf: "center", paddingTop: 10, paddingBottom: 24, gap: 14 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingTop: 4 },
  headerCopy: { flex: 1, alignItems: "flex-end" },
  eyebrow: { fontSize: 13, fontWeight: "800" },
  greeting: { fontSize: 24, fontWeight: "900", marginTop: 3, textAlign: "right" },
  subtitle: { fontSize: 11, marginTop: 5, textAlign: "right" },
  logoMark: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", marginLeft: 12 },
  hero: { minHeight: 142, borderRadius: 24, padding: 20, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  heroText: { alignItems: "flex-end" },
  heroLabel: { color: "#DDF2E5", fontSize: 13, fontWeight: "700" },
  heroPoints: { color: "#FFFFFF", fontSize: 40, fontWeight: "900", marginTop: 3 },
  heroHint: { color: "#B8DCC8", fontSize: 11, marginTop: 3 },
  trophyCircle: { width: 72, height: 72, borderRadius: 36, backgroundColor: "#F8E8B4", alignItems: "center", justifyContent: "center" },
  statsRow: { flexDirection: "row-reverse", gap: 8 },
  statCard: { flex: 1, minHeight: 78, borderWidth: 1, borderRadius: 16, alignItems: "center", justifyContent: "center", paddingHorizontal: 4 },
  statValue: { fontSize: 18, fontWeight: "900", marginTop: 4 },
  statLabel: { fontSize: 9, marginTop: 2, textAlign: "center" },
  sectionHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginTop: 4 },
  sectionTitle: { fontSize: 19, fontWeight: "900", textAlign: "right" },
  sectionHint: { fontSize: 11 },
  featureCard: { minHeight: 82, borderRadius: 20, padding: 14, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  tasbeehCard: { backgroundColor: "#DDF2E5" },
  quizCard: { backgroundColor: "#EAF5FC" },
  rankCard: { backgroundColor: "#FFF8E4" },
  cardIcon: { width: 50, height: 50, borderRadius: 16, backgroundColor: "#C5E8D2", alignItems: "center", justifyContent: "center" },
  cardCopy: { flex: 1, alignItems: "flex-end" },
  featureTitle: { color: "#173F2B", fontSize: 15, fontWeight: "900", textAlign: "right" },
  featureText: { color: "#557064", fontSize: 11, marginTop: 4, textAlign: "right" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.985 }] },
  privacyNote: { fontSize: 10, textAlign: "center", marginTop: -4 },
});
