import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors(); const insets = useSafeAreaInsets(); const bottomPadding = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarButton: HapticTab, tabBarStyle: { paddingTop: 7, paddingBottom: bottomPadding, height: 56 + bottomPadding, backgroundColor: "#FFFFFF", borderTopColor: colors.border, borderTopWidth: 0.5 }, tabBarLabelStyle: { fontSize: 10, fontWeight: "700" } }}>
    <Tabs.Screen name="index" options={{ title: "الرئيسية", tabBarIcon: ({ color }) => <IconSymbol size={23} name="house.fill" color={color} /> }} />
    <Tabs.Screen name="leaderboard" options={{ title: "الصدارة", tabBarIcon: ({ color }) => <IconSymbol size={23} name="trophy.fill" color={color} /> }} />
    <Tabs.Screen name="quiz" options={{ title: "الأسئلة", tabBarIcon: ({ color }) => <IconSymbol size={23} name="book.fill" color={color} /> }} />
    <Tabs.Screen name="tasbeeh" options={{ title: "التسبيح", tabBarIcon: ({ color }) => <IconSymbol size={23} name="circle.grid.2x2.fill" color={color} /> }} />
    <Tabs.Screen name="profile" options={{ title: "حسابي", tabBarIcon: ({ color }) => <IconSymbol size={23} name="person.fill" color={color} /> }} />
  </Tabs>;
}
