import { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { questionBank } from "@/lib/question-bank";
import { addPoints } from "@/lib/local-profile";

export default function QuizScreen() {
  const colors = useColors();
  const [roundQuestions, setRoundQuestions] = useState(() => questionBank.slice(0, 5));
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const current = roundQuestions[index];
  const answered = selected !== null;

  const choose = (option: number) => {
    if (answered) return;
    setSelected(option);
    if (option === current.answer) { setScore((value) => value + 10); void addPoints(10); }
  };
  const next = () => { setSelected(null); if (index === roundQuestions.length - 1) { const start = Math.floor(Math.random() * (questionBank.length - 5)); setRoundQuestions(questionBank.slice(start, start + 5)); setIndex(0); setScore(0); } else { setIndex((value) => value + 1); } };

  return <ScreenContainer className="px-5 pt-4"><View style={styles.container}>
    <View style={styles.header}><View><Text style={[styles.eyebrow, { color: colors.primary }]}>المسابقة اليومية</Text><Text style={[styles.title, { color: colors.foreground }]}>اختبر معلوماتك</Text></View><View style={[styles.pointsPill, { backgroundColor: colors.surface }]}><IconSymbol name="star.fill" size={17} color="#C99A2E" /><Text style={[styles.pointsText, { color: colors.foreground }]}>{score} نقطة</Text></View></View>
    <View style={styles.progressRow}><Text style={[styles.progress, { color: colors.muted }]}>السؤال {index + 1} من {roundQuestions.length}</Text><View style={[styles.progressTrack, { backgroundColor: colors.border }]}><View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${((index + 1) / roundQuestions.length) * 100}%` }]} /></View></View>
    <View style={[styles.questionCard, { backgroundColor: colors.primary }]}><Text style={styles.category}>{current.category}</Text><Text style={styles.question}>{current.question}</Text></View>
    <View style={styles.options}>{current.options.map((option, optionIndex) => { const correct = answered && optionIndex === current.answer; const wrong = answered && optionIndex === selected && !correct; return <Pressable key={option} onPress={() => choose(optionIndex)} style={({ pressed }) => [styles.option, { backgroundColor: correct ? "#E1F4E8" : wrong ? "#FCE8E8" : colors.surface, borderColor: correct ? colors.success : wrong ? colors.error : colors.border }, pressed && !answered && styles.pressed]}><View style={[styles.optionBadge, { backgroundColor: correct ? colors.success : wrong ? colors.error : colors.background }]}><Text style={[styles.optionLetter, { color: correct || wrong ? "#FFFFFF" : colors.primary }]}>{String.fromCharCode(65 + optionIndex)}</Text></View><Text style={[styles.optionText, { color: colors.foreground }]}>{option}</Text>{correct && <IconSymbol name="checkmark.circle.fill" size={22} color={colors.success} />}{wrong && <IconSymbol name="xmark.circle.fill" size={22} color={colors.error} />}</Pressable>; })}</View>
    {answered && <View style={[styles.feedback, { backgroundColor: selected === current.answer ? "#E1F4E8" : "#FFF4D7" }]}><IconSymbol name={selected === current.answer ? "checkmark.circle.fill" : "lightbulb.fill"} size={21} color={selected === current.answer ? colors.success : colors.warning} /><Text style={[styles.feedbackText, { color: colors.foreground }]}>{selected === current.answer ? "إجابة صحيحة! أُضيفت 10 نقاط." : `الإجابة الصحيحة: ${current.options[current.answer]}`}</Text></View>}
    <Pressable onPress={answered ? next : undefined} style={({ pressed }) => [styles.nextButton, { backgroundColor: answered ? colors.primary : colors.border }, pressed && styles.pressed]}><Text style={styles.nextText}>{answered ? "السؤال التالي" : "اختر إجابة"}</Text><IconSymbol name="chevron.left" size={18} color="#FFFFFF" /></Pressable>
  </View></ScreenContainer>;
}

const styles = StyleSheet.create({ container: { flex: 1, gap: 18 }, header: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }, eyebrow: { textAlign: "right", fontSize: 13, fontWeight: "700" }, title: { textAlign: "right", fontSize: 27, fontWeight: "800", marginTop: 3 }, pointsPill: { flexDirection: "row-reverse", gap: 5, alignItems: "center", paddingHorizontal: 11, paddingVertical: 8, borderRadius: 16 }, pointsText: { fontSize: 12, fontWeight: "800" }, progressRow: { gap: 8 }, progress: { textAlign: "right", fontSize: 12, fontWeight: "600" }, progressTrack: { height: 7, borderRadius: 4, overflow: "hidden" }, progressFill: { height: 7, borderRadius: 4 }, questionCard: { borderRadius: 24, padding: 22, minHeight: 155, justifyContent: "center" }, category: { color: "#B9DEC8", fontSize: 13, fontWeight: "700", textAlign: "right", marginBottom: 14 }, question: { color: "#FFFFFF", fontSize: 23, lineHeight: 34, fontWeight: "800", textAlign: "right" }, options: { gap: 10 }, option: { minHeight: 60, borderRadius: 17, borderWidth: 1, flexDirection: "row-reverse", alignItems: "center", padding: 10, gap: 12 }, optionBadge: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" }, optionLetter: { fontWeight: "800" }, optionText: { flex: 1, textAlign: "right", fontSize: 15, fontWeight: "700" }, feedback: { borderRadius: 14, padding: 13, flexDirection: "row-reverse", alignItems: "center", gap: 8 }, feedbackText: { flex: 1, textAlign: "right", fontSize: 13, fontWeight: "700" }, nextButton: { minHeight: 52, borderRadius: 16, flexDirection: "row-reverse", justifyContent: "center", alignItems: "center", gap: 8, marginTop: "auto" }, nextText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" }, pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] } });
